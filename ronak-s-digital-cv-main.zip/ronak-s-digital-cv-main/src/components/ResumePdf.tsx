import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Font,
  Link,
} from "@react-pdf/renderer";
import { resume } from "@/data/resumeData";

Font.register({
  family: "Inter",
  fonts: [
    { src: "https://fonts.gstatic.com/s/inter/v13/UcCO3FwrK3iLTeHuS_fvQtMwCp50KnMw2boKoduKmMEVuLyfAZ9hiA.woff2", fontWeight: 400 },
    { src: "https://fonts.gstatic.com/s/inter/v13/UcCO3FwrK3iLTeHuS_fvQtMwCp50KnMw2boKoduKmMEVuI6fAZ9hiA.woff2", fontWeight: 500 },
    { src: "https://fonts.gstatic.com/s/inter/v13/UcCO3FwrK3iLTeHuS_fvQtMwCp50KnMw2boKoduKmMEVuGKYAZ9hiA.woff2", fontWeight: 600 },
    { src: "https://fonts.gstatic.com/s/inter/v13/UcCO3FwrK3iLTeHuS_fvQtMwCp50KnMw2boKoduKmMEVuFuYAZ9hiA.woff2", fontWeight: 700 },
  ],
});

const styles = StyleSheet.create({
  page: {
    flexDirection: "row",
    backgroundColor: "#ffffff",
    fontFamily: "Inter",
    fontSize: 10,
    padding: 30,
  },
  leftColumn: {
    width: "35%",
    paddingRight: 20,
    borderRightWidth: 1,
    borderRightColor: "#e5e5e5",
  },
  rightColumn: {
    width: "65%",
    paddingLeft: 20,
  },
  name: {
    fontSize: 22,
    fontWeight: 700,
    color: "#1a1a1a",
    marginBottom: 4,
  },
  title: {
    fontSize: 12,
    fontWeight: 500,
    color: "#0d9488",
    marginBottom: 16,
  },
  contactItem: {
    fontSize: 9,
    color: "#525252",
    marginBottom: 6,
  },
  contactLink: {
    fontSize: 9,
    color: "#0d9488",
    marginBottom: 6,
    textDecoration: "none",
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: 600,
    color: "#1a1a1a",
    marginBottom: 10,
    paddingBottom: 4,
    borderBottomWidth: 1,
    borderBottomColor: "#e5e5e5",
  },
  section: {
    marginBottom: 16,
  },
  summaryText: {
    fontSize: 9,
    color: "#525252",
    lineHeight: 1.5,
    marginBottom: 4,
  },
  skillCategory: {
    fontSize: 10,
    fontWeight: 500,
    color: "#1a1a1a",
    marginBottom: 3,
    marginTop: 8,
  },
  skillItems: {
    fontSize: 9,
    color: "#525252",
    lineHeight: 1.4,
  },
  experienceHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 4,
  },
  experienceTitle: {
    fontSize: 10,
    fontWeight: 600,
    color: "#1a1a1a",
  },
  experiencePeriod: {
    fontSize: 9,
    color: "#737373",
  },
  experienceCompany: {
    fontSize: 9,
    color: "#0d9488",
    marginBottom: 6,
  },
  bulletPoint: {
    fontSize: 9,
    color: "#525252",
    marginBottom: 3,
    paddingLeft: 10,
  },
  projectName: {
    fontSize: 10,
    fontWeight: 600,
    color: "#1a1a1a",
    marginBottom: 3,
  },
  projectDescription: {
    fontSize: 9,
    color: "#525252",
    marginBottom: 4,
    lineHeight: 1.4,
  },
  projectTech: {
    fontSize: 8,
    color: "#0d9488",
    marginBottom: 10,
  },
  educationDegree: {
    fontSize: 10,
    fontWeight: 600,
    color: "#1a1a1a",
    marginBottom: 2,
  },
  educationInstitution: {
    fontSize: 9,
    color: "#525252",
    marginBottom: 2,
  },
  educationPeriod: {
    fontSize: 9,
    color: "#737373",
  },
  languagesText: {
    fontSize: 9,
    color: "#525252",
    marginTop: 4,
  },
});

const ResumePdf = () => (
  <Document>
    <Page size="A4" style={styles.page}>
      <View style={styles.leftColumn}>
        <Text style={styles.name}>{resume.name}</Text>
        <Text style={styles.title}>{resume.title}</Text>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Contact</Text>
          <Text style={styles.contactItem}>{resume.location}</Text>
          <Text style={styles.contactItem}>{resume.contacts.email}</Text>
          <Text style={styles.contactItem}>{resume.contacts.phone}</Text>
          <Link src={resume.contacts.github} style={styles.contactLink}>
            GitHub
          </Link>
          <Link src={resume.contacts.linkedin} style={styles.contactLink}>
            LinkedIn
          </Link>
          <Link src={resume.contacts.portfolio} style={styles.contactLink}>
            Portfolio
          </Link>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Skills</Text>
          <Text style={styles.skillCategory}>Backend</Text>
          <Text style={styles.skillItems}>{resume.skills.backend.join(", ")}</Text>
          <Text style={styles.skillCategory}>Frontend</Text>
          <Text style={styles.skillItems}>{resume.skills.frontend.join(", ")}</Text>
          <Text style={styles.skillCategory}>Tools</Text>
          <Text style={styles.skillItems}>{resume.skills.tools.join(", ")}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Languages</Text>
          <Text style={styles.languagesText}>{resume.languages.join(" • ")}</Text>
        </View>
      </View>

      <View style={styles.rightColumn}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Summary</Text>
          {resume.summary.map((line, index) => (
            <Text key={index} style={styles.summaryText}>{line}</Text>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Experience</Text>
          {resume.experience.map((exp, index) => (
            <View key={index} style={{ marginBottom: 12 }}>
              <View style={styles.experienceHeader}>
                <Text style={styles.experienceTitle}>{exp.role}</Text>
                <Text style={styles.experiencePeriod}>{exp.from} – {exp.to}</Text>
              </View>
              <Text style={styles.experienceCompany}>
                {exp.company} • {exp.location}
              </Text>
              {exp.bullets.map((bullet, idx) => (
                <Text key={idx} style={styles.bulletPoint}>
                  • {bullet}
                </Text>
              ))}
            </View>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Projects</Text>
          {resume.projects.map((project, index) => (
            <View key={index}>
              <Text style={styles.projectName}>{project.name}</Text>
              <Text style={styles.projectDescription}>{project.description}</Text>
              <Text style={styles.projectTech}>{project.stack.join(" • ")}</Text>
            </View>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Education</Text>
          {resume.education.map((edu, index) => (
            <View key={index}>
              <Text style={styles.educationDegree}>{edu.degree}</Text>
              <Text style={styles.educationInstitution}>
                {edu.institution}, {edu.location}
              </Text>
              <Text style={styles.educationPeriod}>{edu.year}</Text>
            </View>
          ))}
        </View>
      </View>
    </Page>
  </Document>
);

export default ResumePdf;
