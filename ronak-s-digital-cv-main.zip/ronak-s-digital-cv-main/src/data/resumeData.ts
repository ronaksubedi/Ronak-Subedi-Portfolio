export interface Experience {
  role: string;
  company: string;
  location: string;
  from: string;
  to: string;
  bullets: string[];
}

export interface Project {
  name: string;
  link: string;
  stack: string[];
  description: string;
}

export interface Education {
  degree: string;
  institution: string;
  location: string;
  year: string;
}

export interface ResumeData {
  name: string;
  title: string;
  location: string;
  contacts: {
    email: string;
    phone: string;
    github: string;
    linkedin: string;
    portfolio: string;
  };
  summary: string[];
  skills: {
    backend: string[];
    frontend: string[];
    tools: string[];
  };
  experience: Experience[];
  projects: Project[];
  education: Education[];
  languages: string[];
  interests: string[];
}

export const resume: ResumeData = {
  name: "Ronak Subedi",
  title: "MERN Stack Developer",
  location: "Patan, Bagmati, Nepal",
  contacts: {
    email: "ronaksubedi576@gmail.com",
    phone: "+977-9746975539",
    github: "https://github.com/ronaksubedi",
    linkedin: "https://www.linkedin.com/in/ronak-subedi/",
    portfolio: "https://your-portfolio.com",
  },
  summary: [
    "MERN stack developer focused on building clean, scalable web applications.",
    "Comfortable across MongoDB, Express, React, and Node.js with an eye for performance and DX.",
  ],
  skills: {
    backend: ["Node.js", "Express.js", "REST APIs", "MongoDB"],
    frontend: ["React", "Next.js", "TypeScript", "Tailwind CSS"],
    tools: ["Git", "GitHub", "Postman"],
  },
  experience: [
    {
      role: "MERN Stack Developer",
      company: "Your Company Name",
      location: "Kathmandu, Nepal",
      from: "Jan 2023",
      to: "Present",
      bullets: [
        "Developed and maintained MERN applications used by hundreds of users.",
        "Designed REST APIs in Node.js/Express and integrated them with React frontends.",
        "Improved API response times by optimising MongoDB queries and adding caching.",
      ],
    },
    {
      role: "Full Stack Developer (Intern / Junior)",
      company: "Previous Company",
      location: "Remote",
      from: "Jul 2021",
      to: "Dec 2022",
      bullets: [
        "Implemented new features in existing React applications and fixed UI bugs.",
        "Collaborated with backend team to integrate JSON APIs and WebSocket events.",
        "Wrote reusable components and refactored legacy code for better readability.",
      ],
    },
  ],
  projects: [
    {
      name: "TaskFlow",
      link: "https://taskflow.example.com",
      stack: ["MongoDB", "Express", "React", "Node.js"],
      description:
        "Task management app with real-time updates and JWT-based authentication.",
    },
    {
      name: "DevBlog",
      link: "https://devblog.example.com",
      stack: ["Next.js", "MongoDB", "Tailwind CSS"],
      description:
        "Developer blog platform with markdown support, SEO-friendly routing, and admin dashboard.",
    },
    {
      name: "ShopLite",
      link: "https://shoplite.example.com",
      stack: ["React", "Redux", "Node.js", "MongoDB"],
      description:
        "Lightweight e-commerce prototype with cart, checkout flow, and role-based access.",
    },
  ],
  education: [
    {
      degree: "BSc CSIT",
      institution: "Your College / University",
      location: "Kathmandu, Nepal",
      year: "202X",
    },
  ],
  languages: ["English", "Nepali", "Hindi"],
  interests: ["Open source", "System design", "UI/UX", "Reading tech blogs"],
};
